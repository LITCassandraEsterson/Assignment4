﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class switchController : MonoBehaviour {

    private Animator anim;

    private void Update()
    {
        anim = GetComponent<Animator>();

        anim.SetBool("Pressed", LevelManager.instance.switchPressed);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (Input.GetKeyDown(KeyCode.O) && LevelManager.instance.keyCount > 0)
        {
            LevelManager.instance.switchPressed = !LevelManager.instance.switchPressed;

        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if(Input.GetKeyDown(KeyCode.O) && LevelManager.instance.keyCount>0)
        {
            LevelManager.instance.switchPressed = !LevelManager.instance.switchPressed;

        }
    }
}
